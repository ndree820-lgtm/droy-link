Upload file index.html dan style.css ke repository GitHub droy-link.
Lalu aktifkan GitHub Pages: Settings > Pages > Deploy from a branch > main > /(root) > Save.
